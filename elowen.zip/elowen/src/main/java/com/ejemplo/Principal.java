package com.ejemplo;

import com.amazonaws.services.lambda.runtime.Context;

public class Principal {


    public static void main(String[] args) {
            System.out.println("Valido con exito");
    }
}
