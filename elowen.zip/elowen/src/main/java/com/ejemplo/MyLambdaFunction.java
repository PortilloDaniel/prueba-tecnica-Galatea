package com.ejemplo;


import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.UpdateItemRequest;
import com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;

public class MyLambdaFunction implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {
    private final AmazonDynamoDB dynamoDBClient = AmazonDynamoDBClientBuilder.standard().build();
    private final String TABLE_NAME = "resultados_consultas";

    @Override
    public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent request, Context context) {
        //Tomo el body del request
        String body = request.getBody();

        // extraigo el arreglo de strings del JSON
        String[] manuscrito = parseJson(body);

        // creo el response del código de estado
        APIGatewayProxyResponseEvent response = new APIGatewayProxyResponseEvent();

        if (validacionHVD(manuscrito)) {
            // Si el cuerpo contiene caracteres repetidos, responde con 200
            response.setStatusCode(200);
            response.setBody("OK");
            dynamoDBClient.updateItem(getSuccessRQUpdateItem());

        } else {
            // De lo contrario, responde con 403
            response.setStatusCode(403);
            response.setBody("Forbidden.");
            dynamoDBClient.updateItem(getFailRQUpdateItem());


        }
        return response;
    }


    private UpdateItemRequest getSuccessRQUpdateItem(){
        String id = "2"; // ID del ítem que esta almacenando la información en la base de datos
        //Se crea el RQ del item que se va a actualizar
        UpdateItemRequest updateItemRequest = new UpdateItemRequest()
                .withTableName(TABLE_NAME)
                .addKeyEntry("id", new AttributeValue(id))
                .addAttributeUpdatesEntry("count_clue_found", new AttributeValueUpdate()
                        .withValue(new AttributeValue().withN("1"))
                        .withAction("ADD")) // Incrementa el valor actual del atributo
                .withReturnValues(ReturnValue.UPDATED_NEW);
        return  updateItemRequest;
    }

    private UpdateItemRequest getFailRQUpdateItem(){
        String id = "2"; // ID del ítem que esta almacenando la información en la base de datos
        //Se crea el RQ del item que se va a actualizar
        UpdateItemRequest updateItemRequest = new UpdateItemRequest()
                .withTableName(TABLE_NAME)
                .addKeyEntry("id", new AttributeValue(id))
                .addAttributeUpdatesEntry("count_no_clue", new AttributeValueUpdate()
                        .withValue(new AttributeValue().withN("1"))
                        .withAction("ADD")) // Incrementa el valor actual del atributo
                .withReturnValues(ReturnValue.UPDATED_NEW);
        return  updateItemRequest;
    }

    // Llamado a los 3 casos de las validaciones
    private static boolean validacionHVD(String[] manuscrito) {
        return validacionHorizontal(manuscrito) || validacionVertical(manuscrito) || validacionDiagonal(manuscrito);
    }

    //Validacion horizontal
    private static boolean validacionHorizontal(String[] lineaActual) {
        for (String line : lineaActual) {
            if (existenCaracteresRepetidos(line)) {
                return true;
            }
        }
        return false;
    }
    //Validacion vertical
    private static boolean validacionVertical(String[] lineaActual) {
        int numCols = lineaActual[0].length();
        for (int col = 0; col < numCols; col++) {
            StringBuilder column = new StringBuilder();
            for (String line : lineaActual) {
                column.append(line.charAt(col));
            }
            if (existenCaracteresRepetidos(column.toString())) {
                return true;
            }
        }
        return false;
    }

    //Validacion diagonal
    private static boolean validacionDiagonal(String[] lineaActual) {
        int fila = lineaActual.length;
        int columna = lineaActual[0].length();

        // Diagonales hacia la derecha
        for (int f = 0; f < fila; f++) {
            for (int c = 0; c < columna; c++) {
                if (validacionDiagonalDerecha(lineaActual, f, c)) {
                    return true;
                }
            }
        }

        // Diagonales hacia la izquierda
        for (int f = 0; f < fila; f++) {
            for (int c = columna - 1; c >= 0; c--) {
                if (validacionDiagonalIzquierda(lineaActual, f, c)) {
                    return true;
                }
            }
        }
        return false;
    }

    //Validacion diagonal de derecha a izquierda
    private static boolean validacionDiagonalDerecha(String[] lineaActual, int filaInicial, int columnaInicial) {
        StringBuilder diagonal = new StringBuilder();
        for (int l = filaInicial, c = columnaInicial; l < lineaActual.length && c < lineaActual[0].length(); l++, c++) {
            diagonal.append(lineaActual[l].charAt(c));
        }
        return existenCaracteresRepetidos(diagonal.toString());
    }

    //Validacion diagonal de izquierda a derecha
    private static boolean validacionDiagonalIzquierda(String[] lineaActual, int filaInicial, int columnaInicial) {
        StringBuilder diagonal = new StringBuilder();
        for (int l = filaInicial, c = columnaInicial; l < lineaActual.length && c >= 0; l++, c--) {
            diagonal.append(lineaActual[l].charAt(c));
        }
        return existenCaracteresRepetidos(diagonal.toString());
    }

    //Validacion de existencia de caracteres repetidos
    private static boolean existenCaracteresRepetidos(String lineaActual) {
        int contadorCaracteresRepetidos = 1;
        char ultimoCaracter = lineaActual.charAt(0);
        for (int i = 1; i < lineaActual.length(); i++) {
            if (lineaActual.charAt(i) == ultimoCaracter) {
                contadorCaracteresRepetidos++;
                if (contadorCaracteresRepetidos >= 4) return true;
            } else {
                ultimoCaracter = lineaActual.charAt(i);
                contadorCaracteresRepetidos = 1;
            }
        }
        return false;
    }

    // Método para parsear el JSON manualmente
    private static String[] parseJson(String jsonInput) {
        jsonInput = jsonInput.replaceAll("[{}\"]", ""); // Eliminar llaves y comillas
        String[] parts = jsonInput.split(":");
        String linesPart = parts[1].trim();
        linesPart = linesPart.substring(1, linesPart.length() - 1); // Eliminar corchetes
        return linesPart.split(",\\s*"); // Dividir por coma y espacios
    }





}
